# Flores AI Menu

A colorful personal AI-tools dashboard designed to run on GitHub Pages.

## GitHub Pages setup

1. Create a new GitHub repository.
2. Upload `index.html` and `.nojekyll`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`.
6. Save and wait for GitHub Pages to publish the site.

The login is client-side only:
- Username: `floresAImenu`
- Password: `freeaitools`

Important: because this is a static GitHub Pages website, the credentials are stored in the page source and are NOT secure for protecting sensitive information. This is suitable only as a personal-use gate.
